<?php

define('MODEL_PATH', __DIR__.'/app/models/');
define('CACHE_PATH', __DIR__.'/app/views/cache/');
define('CTRL_PATH', __DIR__.'/app/controllers/');
define('VIEW_PATH',__DIR__.'/app/views/');
